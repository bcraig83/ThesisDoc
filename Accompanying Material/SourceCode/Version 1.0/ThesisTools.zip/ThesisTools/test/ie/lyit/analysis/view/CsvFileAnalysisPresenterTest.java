package ie.lyit.analysis.view;

import ie.lyit.analysis.AnalysisResult;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class CsvFileAnalysisPresenterTest {

	private AnalysisPresenter fixture = null;

	@Before
	public void setUp() throws Exception {
		fixture = new CsvFileAnalysisPresenter();
	}

	@After
	public void tearDown() throws Exception {
		fixture = null;
	}

	@Test
	public void test() {
		AnalysisResult ar = new AnalysisResult();
		ar.setNameOfAnalysis("TotalNumberOfDependencies");

		fixture.presentAnalysis(ar);
	}

	@Test
	public void testPresentAnalysis_nullParameter() {
		fixture.presentAnalysis(null);
	}

}
