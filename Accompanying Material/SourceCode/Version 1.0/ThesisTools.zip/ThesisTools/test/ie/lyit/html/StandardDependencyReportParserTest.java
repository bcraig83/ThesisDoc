package ie.lyit.html;

import static org.junit.Assert.assertNull;

import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class StandardDependencyReportParserTest {

	private DependencyReportParser fixture = null;

	@Before
	public void setUp() throws Exception {
		fixture = new StandardDependencyReportParser();
	}

	@After
	public void tearDown() throws Exception {
		fixture = null;
	}

	@Test
	public void testParse_emptyParameter() {
		assertNull(fixture.parse(""));
	}

	@Test
	public void testParse_nullParameter() {
		assertNull(fixture.parse(null));
	}

	@Test
	public void testParse_realFile() {
		Map<String, String> result = fixture
				.parse("C:\\Users\\Ben Craig\\Dropbox\\College\\Msc Year 3\\Dump\\allReports\\argouml-ThirdParty-DependencyCheck-Report.html");

		System.out.println(result);
	}
}
