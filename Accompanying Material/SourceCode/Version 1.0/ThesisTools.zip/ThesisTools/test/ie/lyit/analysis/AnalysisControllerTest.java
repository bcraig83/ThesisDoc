package ie.lyit.analysis;

import ie.lyit.analysis.strategy.AnalysisStrategy;
import ie.lyit.analysis.strategy.VulnerabilityPerDependencyAnalysisStrategy;
import ie.lyit.xml.AnalysisParser;
import ie.lyit.xml.DirectoryAnalysisParser;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class AnalysisControllerTest {

	// Class under test
	private AnalysisController fixture = null;

	// Dependent classes
	private AnalysisParser analysisParser = null;
	private AnalysisStrategy analysisStrategy = null;

	@Before
	public void setUp() throws Exception {
		analysisParser = new DirectoryAnalysisParser("resources");

		analysisStrategy = new VulnerabilityPerDependencyAnalysisStrategy();

		fixture = new AnalysisController();
		fixture.setAnalysisParser(analysisParser);
	}

	@After
	public void tearDown() throws Exception {
		fixture = null;
		analysisParser = null;
		analysisStrategy = null;
	}

	@Test
	public void test() {
		fixture.addStrategy(analysisStrategy);
		fixture.performAnalysis();
	}

}
