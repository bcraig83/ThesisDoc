package ie.lyit.analysis.view;

import ie.lyit.analysis.AnalysisResult;

import java.io.OutputStreamWriter;

public class FileAnalysisPresenter implements AnalysisPresenter {

	// private File
	protected OutputStreamWriter writer = null;

	// public FileAnalysisPresenter(File file) throws FileNotFoundException {
	//
	// FileOutputStream fos = new FileOutputStream(file);
	// writer = new OutputStreamWriter(fos);
	// }

	@Override
	public void presentAnalysis(AnalysisResult analysisResult) {
		// TODO Create a generic file writer, don't really care how the data
		// looks, just write it to a file
	}

}
