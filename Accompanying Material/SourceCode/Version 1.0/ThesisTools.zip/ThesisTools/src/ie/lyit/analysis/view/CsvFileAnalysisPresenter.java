package ie.lyit.analysis.view;

import ie.lyit.analysis.AnalysisResult;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class CsvFileAnalysisPresenter extends FileAnalysisPresenter {

	@Override
	public void presentAnalysis(AnalysisResult analysisResult) {
		// TODO: this is all file-specific NOT csvFile specific so should be
		// moved up to FileAnalysisPresenter

		// TODO: can also do some more neat stuff like put the files in a
		// consistent directory structure instead of dumping them all in the
		// project directory

		if (analysisResult == null) {
			return;
		}

		try {
			String analysisName = analysisResult.getNameOfAnalysis();

			String filename = new SimpleDateFormat("yyyyMMdd'T'hhmm'.csv'")
					.format(new Date());

			StringBuffer sb = new StringBuffer();
			sb.append(analysisName);
			sb.append("-");
			sb.append(filename);

			File file = new File(sb.toString());

			file.createNewFile();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
