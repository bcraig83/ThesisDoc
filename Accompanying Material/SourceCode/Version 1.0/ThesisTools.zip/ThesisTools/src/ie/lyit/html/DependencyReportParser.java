package ie.lyit.html;

import java.util.Map;

public interface DependencyReportParser {

	public Map<String, String> parse(String path);

}
