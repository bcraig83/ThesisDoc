package ie.lyit;

import ie.lyit.analysis.AnalysisController;
import ie.lyit.analysis.strategy.VulnerabilityPerDependencyAnalysisStrategy;
import ie.lyit.analysis.view.AnalysisPresenter;
import ie.lyit.analysis.view.CsvFileAnalysisPresenter;
import ie.lyit.xml.AnalysisParser;
import ie.lyit.xml.DirectoryAnalysisParser;

public class Main {

	// Takes a single parameter, the path to the directory containing all the
	// XML files
	// TODO: add usage instructions, validation on arguments, etc.
	public static void main(String[] args) {
		String path = args[0];

		System.out.println(path);

		Main controller = new Main(path);
		controller.execute();
	}

	private AnalysisParser parser = null;
	private AnalysisController analysisController = null;
	private AnalysisPresenter analysisPresenter = null;

	public Main(String path) {
		parser = new DirectoryAnalysisParser(path);
		analysisPresenter = new CsvFileAnalysisPresenter();

		analysisController = new AnalysisController();
		analysisController
				.addStrategy(new VulnerabilityPerDependencyAnalysisStrategy());

		analysisController.setAnalysisParser(parser);
		analysisController.setAnalysisPresenter(analysisPresenter);
	}

	public void execute() {
		analysisController.performAnalysis();
	}
}
