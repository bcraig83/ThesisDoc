package ie.lyit.analysis.strategy;

import https.www_owasp_org.index_php.owasp_dependency_check.Analysis;
import ie.lyit.analysis.AnalysisResult;

public interface AnalysisStrategy {

	public AnalysisResult getAnalysisResult();

	// TODO: is it correct to make the method generic; or the class?
	// Answer: neither?
	public void performAnalysis(Analysis analysis);

	// TODO: need to figure out how we want the result data to be displayed
	// (e.g. how in a CSV file, where the project name goes, etc.
}
