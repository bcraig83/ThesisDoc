package ie.lyit.analysis;

import https.www_owasp_org.index_php.owasp_dependency_check.Analysis;
import ie.lyit.analysis.strategy.AnalysisStrategy;
import ie.lyit.analysis.view.AnalysisPresenter;
import ie.lyit.xml.AnalysisParser;

import java.util.ArrayList;
import java.util.List;

public class AnalysisController {

	private AnalysisParser analysisParser = null;
	private List<AnalysisStrategy> analysisStrategyList = null;
	private AnalysisPresenter analysisPresenter = null;

	public void addStrategy(AnalysisStrategy analysisStrategy) {
		if (analysisStrategyList == null) {
			analysisStrategyList = new ArrayList<AnalysisStrategy>();
		}

		analysisStrategyList.add(analysisStrategy);
	}

	public void performAnalysis() {
		if (analysisParser == null || analysisStrategyList == null
				|| analysisPresenter == null) {
			System.out
					.println("Trying to perform analysis without setting required members...");
			return;
		}

		// Step 1: Parse the XML files
		List<Analysis> analysisList = analysisParser.parse();

		// Step 2: For each analysis object, apply each AnalyisStrategy

		for (Analysis analysis : analysisList) {
			for (AnalysisStrategy as : analysisStrategyList) {
				as.performAnalysis(analysis);
				AnalysisResult ar = as.getAnalysisResult();

				// Step 3: For each analysisResult, apply the presentation logic

				analysisPresenter.presentAnalysis(ar);
			}
		}
	}

	// May re-write how these components are all wired up
	public void setAnalysisParser(AnalysisParser analysisParser) {
		this.analysisParser = analysisParser;
	}

	public void setAnalysisPresenter(AnalysisPresenter analysisPresenter) {
		this.analysisPresenter = analysisPresenter;
	}

}
