package ie.lyit.analysis.strategy;

import https.www_owasp_org.index_php.owasp_dependency_check.Analysis;
import ie.lyit.analysis.AnalysisResult;

public abstract class AbstractAnalysisStrategy implements AnalysisStrategy {

	private AnalysisResult analysisResult = null;

	@Override
	public AnalysisResult getAnalysisResult() {
		if (analysisResult == null) {
			analysisResult = new AnalysisResult();
		}

		return analysisResult;
	}

	protected boolean isAnalysisObjectValid(Analysis analysis) {
		if (analysis == null) {
			return false;
		}

		getAnalysisResult().setNameOfProject(
				analysis.getProjectInfo().getName());

		return true;
	}
}
