package ie.lyit.analysis;

public class AnalysisResult {

	private String nameOfProject = null;
	private String nameOfAnalysis = null;
	private String resultOfAnalysis = null;

	public String getNameOfAnalysis() {
		return nameOfAnalysis;
	}

	public String getNameOfProject() {
		return nameOfProject;
	}

	public String getResultOfAnalysis() {
		return resultOfAnalysis;
	}

	public void setNameOfAnalysis(String nameOfAnalysis) {
		this.nameOfAnalysis = nameOfAnalysis;
	}

	public void setNameOfProject(String nameOfProject) {
		this.nameOfProject = nameOfProject;
	}

	public void setResultOfAnalysis(String resultOfAnalysis) {
		this.resultOfAnalysis = resultOfAnalysis;
	}

}
