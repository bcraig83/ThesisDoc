package ie.lyit.wrapper;

import https.www_owasp_org.index_php.owasp_dependency_check.Analysis;

@Deprecated
public abstract class AnalysisWrapper {
	protected Analysis analysis = null;

	public AnalysisWrapper(Analysis analysis) {
		this.analysis = analysis;
	}
}
