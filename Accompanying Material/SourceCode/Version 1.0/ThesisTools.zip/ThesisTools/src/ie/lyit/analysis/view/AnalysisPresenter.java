package ie.lyit.analysis.view;

import ie.lyit.analysis.AnalysisResult;

public interface AnalysisPresenter {

	public void presentAnalysis(AnalysisResult analysisResult);
}
