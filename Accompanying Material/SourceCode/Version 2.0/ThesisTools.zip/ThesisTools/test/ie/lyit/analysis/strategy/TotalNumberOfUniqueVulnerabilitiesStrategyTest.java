package ie.lyit.analysis.strategy;

import static org.junit.Assert.assertEquals;
import https.www_owasp_org.index_php.owasp_dependency_check.Analysis;
import https.www_owasp_org.index_php.owasp_dependency_check.Analysis.Dependencies.Dependency.Vulnerabilities.Vulnerability;
import ie.lyit.analysis.AnalysisResult;
import ie.lyit.analysis.builder.VulnerabilityBuilder;
import ie.lyit.analysis.factory.AnalysisFactory;
import ie.lyit.analysis.factory.DefaultAnalysisFactory;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class TotalNumberOfUniqueVulnerabilitiesStrategyTest {

	private Analysis analysis = null;
	private AnalysisFactory analysisFactory = null;
	private List<Analysis> analysisList = null;
	private AnalysisResult analysisResult = null;
	private AnalysisStrategy fixture = null;
	private VulnerabilityBuilder vulnerabilityBuilder = null;

	@Before
	public void setUp() throws Exception {
		fixture = new TotalNumberOfUniqueVulnerabilitiesStrategy();
		analysisFactory = new DefaultAnalysisFactory();

		analysis = analysisFactory.create();

		analysisList = new ArrayList<Analysis>();
		vulnerabilityBuilder = new VulnerabilityBuilder();
	}

	@After
	public void tearDown() throws Exception {
		fixture = null;
		analysisFactory = null;
		analysisResult = null;
		analysis = null;
		analysisList = null;
		vulnerabilityBuilder = null;
	}

	@Test
	public void testPerformAnalysis() {

		analysisList.add(analysis);

		analysisResult = fixture.getAnalysisResult();
		assertEquals(0, analysisResult.getResultMap().size());

		fixture.performAnalysis(analysisList);
		assertEquals(new Double(1.0), analysisResult.getResultMap().get("TestProject"));
	}

	@Test
	public void testPerformAnalysis_nullParameter() {
		analysisResult = fixture.getAnalysisResult();
		assertEquals(0, analysisResult.getResultMap().size());

		fixture.performAnalysis(null);
		assertEquals(0, analysisResult.getResultMap().size());

	}

	@Test
	public void testPerformAnalysis_threeVulnerabilities_twoUnique() {

		Vulnerability vulnerability1 = vulnerabilityBuilder.name("CWE-2001-1567").build();
		Vulnerability vulnerability2 = vulnerabilityBuilder.name("CWE-2007-7876").build();

		analysisFactory.addVulnerability(vulnerability1);
		analysisFactory.addVulnerability(vulnerability2);
		analysisFactory.addVulnerability(vulnerability2);

		analysis = analysisFactory.create();

		analysisList.add(analysis);

		fixture.performAnalysis(analysisList);
		analysisResult = fixture.getAnalysisResult();
		assertEquals(2.0, analysisResult.getResultMap().get("TestProject"), 0);
	}
}
