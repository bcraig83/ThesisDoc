package ie.lyit.analysis.strategy.utility;

import https.www_owasp_org.index_php.owasp_dependency_check.Analysis;
import https.www_owasp_org.index_php.owasp_dependency_check.Analysis.Dependencies;
import https.www_owasp_org.index_php.owasp_dependency_check.Analysis.Dependencies.Dependency;
import https.www_owasp_org.index_php.owasp_dependency_check.Analysis.Dependencies.Dependency.Vulnerabilities;
import https.www_owasp_org.index_php.owasp_dependency_check.Analysis.Dependencies.Dependency.Vulnerabilities.Vulnerability;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AnalysisUtil {

	public static List<Dependency> extractDependencyList(Analysis analysis) {

		if (analysis == null) {
			return new ArrayList<Dependency>();
		}

		Dependencies dependencies = analysis.getDependencies();
		if (dependencies == null) {
			System.out.println("Warn: no dependencies");
			return new ArrayList<Dependency>();
		}

		List<Dependency> dependencyList = dependencies.getDependency();

		if (dependencyList == null) {
			System.out.println("Error: dependency list is null!");
		}

		return dependencyList;
	}

	public static List<Vulnerability> extractVulnerabilities(
			Dependency dependency) {

		if (dependency == null) {
			return null;
		}
		Vulnerabilities vulnerabilities = dependency.getVulnerabilities();

		if (vulnerabilities == null) {
			// System.out.println("Info: no vulnerabilities found in dependency "
			// + dependency.getFileName());
			return null;
		}

		return vulnerabilities.getVulnerability();

	}

	// TODO: Unit tests!
	public static double getTotalDependencies(Analysis analysis) {

		if (analysis == null) {
			return 0;
		}
		return extractDependencyList(analysis).size();
	}

	public static double getTotalUniqueVulnerabilities(Analysis analysis) {

		if (analysis == null) {
			return 0;
		}
		Map<String, Vulnerability> uniqueVulnerabilities = new HashMap<String, Vulnerability>();

		List<Dependency> dependencyList = extractDependencyList(analysis);

		for (Dependency dependency : dependencyList) {

			List<Vulnerability> vulnerabilityList = extractVulnerabilities(dependency);

			if (vulnerabilityList == null) {
				continue;
			}

			for (Vulnerability vulnerability : vulnerabilityList) {
				String name = vulnerability.getName();
				if (!uniqueVulnerabilities.containsKey(name)) {
					uniqueVulnerabilities.put(name, vulnerability);
				}
			}
		}

		return uniqueVulnerabilities.size();
	}

	public static double getTotalVulnerabilities(Analysis analysis) {
		if (analysis == null) {
			return 0;
		}
		int totalVulnerabilites = 0;

		List<Dependency> dependencyList = extractDependencyList(analysis);

		for (Dependency dependency : dependencyList) {
			totalVulnerabilites += getTotalVulnerabilities(dependency);
		}

		return totalVulnerabilites;
	}

	public static int getTotalVulnerabilities(Dependency dependency) {
		if (dependency == null) {
			return 0;
		}
		int totalVulnerabilites = 0;

		List<Vulnerability> vulnerabilityList = extractVulnerabilities(dependency);

		if (vulnerabilityList == null) {
			return 0;
		}

		totalVulnerabilites += vulnerabilityList.size();

		return totalVulnerabilites;
	}
}