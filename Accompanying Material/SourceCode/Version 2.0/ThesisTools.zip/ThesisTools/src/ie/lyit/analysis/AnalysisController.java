package ie.lyit.analysis;

import https.www_owasp_org.index_php.owasp_dependency_check.Analysis;
import ie.lyit.analysis.strategy.AnalysisStrategy;
import ie.lyit.analysis.view.AnalysisPresenter;
import ie.lyit.xml.AnalysisParser;

import java.util.ArrayList;
import java.util.List;

public class AnalysisController {

	private AnalysisParser analysisParser = null;
	private AnalysisPresenter analysisPresenter = null;
	private List<AnalysisStrategy> analysisStrategyList = null;

	public void addStrategy(AnalysisStrategy analysisStrategy) {
		if (analysisStrategyList == null) {
			analysisStrategyList = new ArrayList<AnalysisStrategy>();
		}

		analysisStrategyList.add(analysisStrategy);
	}

	public void performAnalysis() {
		if (analysisParser == null || analysisStrategyList == null
				|| analysisPresenter == null) {
			System.out
					.println("Trying to perform analysis without setting required members...");
			return;
		}

		// Step 1: Parse all of the files in the directory provided
		System.out.println("Parsing Files...");
		List<Analysis> analysisList = analysisParser.parse();

		// Step 2: For each AnalysisStrategy, apply it to the list of all
		// Analysis objects
		System.out.println("Analysing...");
		for (AnalysisStrategy as : analysisStrategyList) {
			as.performAnalysis(analysisList);
			AnalysisResult ar = as.getAnalysisResult();

			// Step 3: For each analysisResult, apply the presentation logic
			analysisPresenter.presentAnalysis(ar);
		}

		System.out.println("Done");
	}

	// May re-write how these components are all wired up
	public void setAnalysisParser(AnalysisParser analysisParser) {
		this.analysisParser = analysisParser;
	}

	public void setAnalysisPresenter(AnalysisPresenter analysisPresenter) {
		this.analysisPresenter = analysisPresenter;
	}
}