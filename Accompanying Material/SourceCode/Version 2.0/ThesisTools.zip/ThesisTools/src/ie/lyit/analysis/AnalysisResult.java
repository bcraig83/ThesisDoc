package ie.lyit.analysis;

import java.util.HashMap;
import java.util.Map;

// TODO: add some JavaDocs on how this class works!
public class AnalysisResult {

	private String nameOfAnalysis = null;
	private Map<String, Double> resultMap = null;
	private String typeOfItemOfInterest = null;

	public AnalysisResult() {
		resultMap = new HashMap<String, Double>();
	}

	public void add(String t, Double i) {
		// System.out.println("Before: " + resultMap.get(t));

		Double value = resultMap.get(t);

		if (value == null) {
			resultMap.put(t, i);
			return;
		}

		value += i;

		resultMap.put(t, value);

		// System.out.println("After: " + resultMap.get(t));
	}

	public String getNameOfAnalysis() {
		return nameOfAnalysis;
	}

	// TODO: expose a get method that can take a String and return the result
	// from the Map directly. Makes for a cleaner interface
	public Map<String, Double> getResultMap() {
		return resultMap;
	}

	/**
	 * Return the 'type' of what's being analysed. This can be used as the first
	 * heading in a CSV file for example. It may be "Project", "Vulnerability",
	 * 
	 * Note that I may include more advanced analysis which might contain
	 * multiple headings. Need to figure out how to handle that if needed
	 * 
	 * @return
	 */
	public String getTypeOfItemOfInterest() {
		return typeOfItemOfInterest;
	}

	public void increment(String t) {
		add(t, 1.0);
	}

	public void setNameOfAnalysis(String nameOfAnalysis) {
		this.nameOfAnalysis = nameOfAnalysis;
	}

	public void setTypeOfItemOfInterest(String typeOfItemOfInterest) {
		this.typeOfItemOfInterest = typeOfItemOfInterest;
	}

}
