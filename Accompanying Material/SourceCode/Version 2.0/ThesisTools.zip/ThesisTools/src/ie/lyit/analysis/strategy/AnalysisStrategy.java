package ie.lyit.analysis.strategy;

import https.www_owasp_org.index_php.owasp_dependency_check.Analysis;
import ie.lyit.analysis.AnalysisResult;

import java.util.List;

public interface AnalysisStrategy {
	public AnalysisResult getAnalysisResult();

	public void performAnalysis(List<Analysis> analysisList);

	// This needed to be changed to a list, since a single 'report' can contain
	// multiple Analysis objects
}
