package ie.lyit.analysis.strategy;

import https.www_owasp_org.index_php.owasp_dependency_check.Analysis;
import https.www_owasp_org.index_php.owasp_dependency_check.Analysis.Dependencies.Dependency;
import https.www_owasp_org.index_php.owasp_dependency_check.Analysis.Dependencies.Dependency.Vulnerabilities.Vulnerability;
import ie.lyit.analysis.AnalysisResult;
import ie.lyit.analysis.strategy.utility.AnalysisUtil;

import java.util.List;

public class VulnerableJarDistributionStrategy extends AbstractAnalysisStrategy {

	@Override
	public void performAnalysis(List<Analysis> analysisList) {
		if (analysisList == null) {
			return;
		}

		for (Analysis analysis : analysisList) {
			AnalysisResult aar = getAnalysisResult();

			aar.setNameOfAnalysis("Vulnerable JAR File Distribution");
			aar.setTypeOfItemOfInterest("JAR File");

			List<Dependency> dependencyList = AnalysisUtil
					.extractDependencyList(analysis);
			for (Dependency dependency : dependencyList) {

				List<Vulnerability> vulnerabilityList = AnalysisUtil
						.extractVulnerabilities(dependency);

				if (vulnerabilityList == null) {
					continue;
				}
				aar.increment(dependency.getFileName());
			}
		}
	}
}