package ie.lyit.analysis;

@Deprecated
public class AnalysisException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8030030356885814082L;

}
