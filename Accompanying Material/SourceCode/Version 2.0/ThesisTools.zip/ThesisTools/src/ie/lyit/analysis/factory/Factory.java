package ie.lyit.analysis.factory;

public interface Factory<T> {
	public T create();
}
