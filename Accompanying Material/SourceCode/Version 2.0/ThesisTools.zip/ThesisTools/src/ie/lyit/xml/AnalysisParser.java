package ie.lyit.xml;

import https.www_owasp_org.index_php.owasp_dependency_check.Analysis;

import java.util.List;

public interface AnalysisParser {

	public List<Analysis> parse();
}
