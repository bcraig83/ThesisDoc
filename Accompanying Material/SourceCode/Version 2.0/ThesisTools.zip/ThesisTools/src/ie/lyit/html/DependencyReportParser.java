package ie.lyit.html;

import java.util.Map;

@Deprecated
public interface DependencyReportParser {

	public Map<String, String> parse(String path);

}
