package ie.lyit.analysis.view;

// TODO: do I need this?
public abstract class FileAnalysisPresenter implements AnalysisPresenter {

}
