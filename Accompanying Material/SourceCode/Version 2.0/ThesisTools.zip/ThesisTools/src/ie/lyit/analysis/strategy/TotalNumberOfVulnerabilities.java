package ie.lyit.analysis.strategy;

import https.www_owasp_org.index_php.owasp_dependency_check.Analysis;
import ie.lyit.analysis.AnalysisResult;
import ie.lyit.analysis.strategy.utility.AnalysisUtil;

import java.util.List;

public class TotalNumberOfVulnerabilities extends AbstractAnalysisStrategy {

	@Override
	public void performAnalysis(List<Analysis> analysisList) {
		if (analysisList == null) {
			return;
		}
		for (Analysis analysis : analysisList) {
			// TODO: this check is repeated in multiple places; should probably
			// try and avoid this duplication (Template design pattern?)
			if (!isAnalysisObjectValid(analysis)) {
				return;
			}
			AnalysisResult ar = getAnalysisResult();
			ar.setNameOfAnalysis("Total Number of Vulnerabilities");
			ar.setTypeOfItemOfInterest("Project name");

			ar.add(analysis.getProjectInfo().getName(),
					AnalysisUtil.getTotalVulnerabilities(analysis));
		}
	}
}