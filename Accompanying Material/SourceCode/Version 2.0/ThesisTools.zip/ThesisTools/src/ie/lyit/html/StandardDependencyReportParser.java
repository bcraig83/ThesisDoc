package ie.lyit.html;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

@Deprecated
public class StandardDependencyReportParser implements DependencyReportParser {

	// TODO: rather than return a map, I could create a domain object that can
	// hold an enum (source or third party), system name and no. of violations

	@Override
	public Map<String, String> parse(String path) {

		if (StringUtils.isEmpty(path)) {
			return null;
		}

		Map<String, String> result = new HashMap<String, String>();

		String line;
		int start;
		int end;

		try {
			FileReader fileReader = new FileReader(path);

			BufferedReader bufferedReader = new BufferedReader(fileReader);

			if (path.contains("Source")) {
				result.put("Type", "Source");
			} else if (path.contains("ThirdParty")) {
				result.put("Type", "ThirdParty");
			}

			// TODO: make this alot more abstract & extensible
			while ((line = bufferedReader.readLine()) != null) {
				if (line.contains("Project:")) {
					start = line.indexOf(";");
					end = line.indexOf("</h2>");

					String systemName = line.substring(start + 1, end);
					// System.out.println(systemName);
					result.put("System", systemName);
				}

				if (line.contains("Dependencies Scanned")) {
					start = line.indexOf("sp;");
					end = line.lastIndexOf("&nb");

					String dependenciesScanned = line.substring(start + 3, end);
					// System.out.println(dependenciesScanned);
					result.put("Dependencies Scanned", dependenciesScanned);
				}

				if (line.contains("Vulnerable Dependencies")) {
					start = line.indexOf(";");
					end = line.indexOf("<br/>");

					String vulnerabilities = line.substring(start + 1, end);
					// System.out.println(vulnerabilities);
					result.put("Vulnerabilities", vulnerabilities);
				}

			}
			bufferedReader.close();

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return result;
	}
}
