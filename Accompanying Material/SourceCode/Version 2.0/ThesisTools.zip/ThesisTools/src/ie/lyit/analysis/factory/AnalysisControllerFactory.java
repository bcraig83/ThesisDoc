package ie.lyit.analysis.factory;

import ie.lyit.analysis.AnalysisController;
import ie.lyit.analysis.strategy.TotalNumberOfDependenciesStrategy;
import ie.lyit.analysis.strategy.TotalNumberOfUniqueVulnerabilitiesStrategy;
import ie.lyit.analysis.strategy.TotalNumberOfVulnerabilities;
import ie.lyit.analysis.strategy.VulnerabilityPerDependencyAnalysisStrategy;
import ie.lyit.analysis.strategy.VulnerabilitySeverityDistributionStrategy;
import ie.lyit.analysis.strategy.VulnerableJarDistributionStrategy;
import ie.lyit.analysis.view.AnalysisPresenter;
import ie.lyit.analysis.view.CsvFileAnalysisPresenter;
import ie.lyit.xml.AnalysisParser;
import ie.lyit.xml.DirectoryAnalysisParser;

public class AnalysisControllerFactory implements Factory<AnalysisController> {

	// Could all be wired using Spring...
	private AnalysisController analysisController = null;
	private AnalysisPresenter analysisPresenter = null;
	private AnalysisParser parser = null;
	private String path = null;

	public AnalysisControllerFactory(String path) {
		this.path = path;
	}

	@Override
	public AnalysisController create() {

		parser = new DirectoryAnalysisParser(path);
		analysisPresenter = new CsvFileAnalysisPresenter();

		analysisController = new AnalysisController();

		// Add whatever strategies we want to run...
		analysisController.addStrategy(new VulnerableJarDistributionStrategy());

		analysisController
				.addStrategy(new VulnerabilitySeverityDistributionStrategy());
		analysisController
				.addStrategy(new TotalNumberOfUniqueVulnerabilitiesStrategy());
		analysisController
				.addStrategy(new VulnerabilityPerDependencyAnalysisStrategy());
		analysisController.addStrategy(new TotalNumberOfDependenciesStrategy());
		analysisController.addStrategy(new TotalNumberOfVulnerabilities());

		analysisController.setAnalysisParser(parser);
		analysisController.setAnalysisPresenter(analysisPresenter);

		return analysisController;
	}

}
