package ie.lyit.analysis.strategy;

import https.www_owasp_org.index_php.owasp_dependency_check.Analysis;
import ie.lyit.analysis.AnalysisResult;
import ie.lyit.analysis.strategy.utility.AnalysisUtil;

import java.util.List;

public class TotalNumberOfDependenciesStrategy extends AbstractAnalysisStrategy {

	// TODO: definitely a better way to structure this performAnalysis method
	@Override
	public void performAnalysis(List<Analysis> analysisList) {
		if (analysisList == null) {
			return;
		}

		for (Analysis analysis : analysisList) {
			if (!isAnalysisObjectValid(analysis)) {
				return;
			}

			AnalysisResult ar = getAnalysisResult();
			ar.setNameOfAnalysis("Total Number of Dependencies");

			ar.setTypeOfItemOfInterest("Project name");

			ar.add(analysis.getProjectInfo().getName(),
					AnalysisUtil.getTotalDependencies(analysis));
		}
	}
}