package ie.lyit.html;

import java.io.File;
import java.util.Iterator;
import java.util.Map;

import org.apache.commons.io.FileUtils;

@Deprecated
public class Execute {

	public static void main(final String[] args) throws Exception {
		System.out.println("Processing...");
		DependencyReportParser drp = new StandardDependencyReportParser();
		Map<String, String> map = null;

		Iterator<File> it = FileUtils
				.iterateFiles(
						new File(
								"C:\\Users\\Ben Craig\\Dropbox\\College\\Msc Year 3\\Dump\\allReports"),
						null, false);

		FileUtils
				.write(new File(
						"C:\\Users\\Ben Craig\\Dropbox\\College\\Msc Year 3\\Dump\\allReports\\results.csv"),
						"Type,Dependencies,System,Vulnerabilities\n");

		while (it.hasNext()) {
			String path = it.next().getAbsolutePath();

			map = drp.parse(path);

			for (Map.Entry<String, String> entry : map.entrySet()) {
				FileUtils
						.write(new File(
								"C:\\Users\\Ben Craig\\Dropbox\\College\\Msc Year 3\\Dump\\allReports\\results.csv"),
								entry.getValue() + ",", true);
			}

			FileUtils
					.write(new File(
							"C:\\Users\\Ben Craig\\Dropbox\\College\\Msc Year 3\\Dump\\allReports\\results.csv"),
							"\n", true);
		}

		System.out.println("Done");
	}
}
