package ie.lyit.analysis.view;

import ie.lyit.analysis.AnalysisResult;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;

import org.apache.commons.io.FileUtils;

public class CsvFileAnalysisPresenter extends FileAnalysisPresenter {

	private File createFile(AnalysisResult analysisResult) {
		String directoryName = new SimpleDateFormat("yyyy-MM-dd")
				.format(new Date());

		String timestamp = new SimpleDateFormat("hhmmss").format(new Date());

		StringBuffer fileName = new StringBuffer();
		fileName.append("reports");
		fileName.append("\\");
		fileName.append(directoryName);
		fileName.append("\\");
		fileName.append(timestamp);
		fileName.append("\\");
		fileName.append(analysisResult.getNameOfAnalysis());
		fileName.append(".csv");

		return new File(fileName.toString());
	}

	@Override
	public void presentAnalysis(AnalysisResult analysisResult) {
		// TODO: this is mostly file-specific NOT csvFile-specific so should be
		// moved up to FileAnalysisPresenter

		if (analysisResult == null) {
			return;
		}

		File file = createFile(analysisResult);

		writeHeadings(file, analysisResult);
		writeData(file, analysisResult);

	}

	private void writeData(File file, AnalysisResult analysisResult) {
		try {

			Map<String, Double> resultMap = analysisResult.getResultMap();

			Iterator<?> it = resultMap.entrySet().iterator();
			while (it.hasNext()) {
				Map.Entry pairs = (Map.Entry) it.next();
				// System.out.println(pairs.getKey() + " = " +
				// pairs.getValue());

				StringBuffer singleRow = new StringBuffer();
				singleRow.append(pairs.getKey());
				singleRow.append(",");
				singleRow.append(pairs.getValue());
				singleRow.append("\n");
				FileUtils.writeStringToFile(file, singleRow.toString(), true);

				it.remove(); // avoids a ConcurrentModificationException
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void writeHeadings(File file, AnalysisResult analysisResult) {
		if (!file.exists()) {
			try {
				StringBuffer headings = new StringBuffer();

				headings.append(analysisResult.getTypeOfItemOfInterest());
				headings.append(",");
				headings.append(analysisResult.getNameOfAnalysis());
				headings.append("\n");

				FileUtils.writeStringToFile(file, headings.toString(), true);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
