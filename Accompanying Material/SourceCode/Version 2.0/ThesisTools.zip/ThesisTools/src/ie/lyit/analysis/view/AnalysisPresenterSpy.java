package ie.lyit.analysis.view;

import ie.lyit.analysis.AnalysisResult;

import java.util.HashMap;
import java.util.Map;

public class AnalysisPresenterSpy implements AnalysisPresenter {

	// Horrible! TODO: make this a bit more pleasing to the eye.
	private Map<String, Map<String, Double>> resultMap = new HashMap<String, Map<String, Double>>();

	private Map<String, String> typeOfItemOfInterestMap = new HashMap<String, String>();

	public Map<String, Map<String, Double>> getResultMap() {
		return resultMap;
	}

	public Map<String, String> getTypeOfItemOfInterestMap() {
		return typeOfItemOfInterestMap;
	}

	@Override
	public void presentAnalysis(AnalysisResult analysisResult) {
		String nameOfAnalysis = analysisResult.getNameOfAnalysis();
		resultMap.put(nameOfAnalysis, analysisResult.getResultMap());

		typeOfItemOfInterestMap.put(nameOfAnalysis,
				analysisResult.getTypeOfItemOfInterest());

	}
}